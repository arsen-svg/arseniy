document.addEventListener('DOMContentLoaded', () => {
    // Мобильное меню
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
  
    hamburger?.addEventListener('click', () => {
      navLinks.classList.toggle('active');
      hamburger.classList.toggle('open');
    });
  
    // Закрытие меню при клике вне области
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.navbar')) {
        navLinks?.classList.remove('active');
        hamburger?.classList.remove('open');
      }
    });
  });
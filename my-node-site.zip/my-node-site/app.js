const express = require('express');
const app = express();
const port = 3000;

// Настройка EJS
app.set('view engine', 'ejs');

// Middleware
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

// Маршруты
app.get('/', (req, res) => {
  res.render('index', { 
    title: 'Главная',
    activePage: 'home'
  });
});

app.get('/about', (req, res) => {
  res.render('about', { 
    title: 'О нас',
    activePage: 'about',
    team: [
      { name: 'Алексей', position: 'Разработчик' },
      { name: 'Мария', position: 'Дизайнер' },
      { name: 'Иван', position: 'Менеджер' }
    ]
  });
});

app.get('/services', (req, res) => {
  res.render('services', {
    title: 'Услуги',
    activePage: 'services',
    services: [
      { name: 'Веб-разработка', price: 'от 20 000₽' },
      { name: 'Дизайн', price: 'от 15 000₽' },
      { name: 'SEO', price: 'от 10 000₽' }
    ]
  });
});

app.get('/contact', (req, res) => {
  res.render('contact', {
    title: 'Контакты',
    activePage: 'contact'
  });
});

app.post('/contact', (req, res) => {
  console.log('Форма отправлена:', req.body);
  res.redirect('/thank-you');
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    title: 'Спасибо!'
  });
});

// 404
app.use((req, res) => {
  res.status(404).render('404', {
    title: 'Страница не найдена'
  });
});

// Запуск сервера
app.listen(port, () => {
  console.log(`Сервер запущен на http://localhost:${port}`);
});
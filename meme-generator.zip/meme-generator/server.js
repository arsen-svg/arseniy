require('dotenv').config();
const express = require('express');
const session = require('express-session');
const flash = require('connect-flash');
const multer = require('multer');
const path = require('path');
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');
const bodyParser = require('body-parser');
const fs = require('fs'); // Добавлен модуль для работы с файловой системой

const app = express();

// Настройка базы данных
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'meme_generator',
  namedPlaceholders: true
};

// Настройка сессий
app.use(session({
  secret: 'secret-key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }
}));

app.use(flash());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Настройка EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Настройка Multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

// Промежуточное ПО
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  next();
});

// Подключение к БД
async function getConnection() {
  return await mysql.createConnection(dbConfig);
}

// Проверка аутентификации
function ensureAuthenticated(req, res, next) {
  req.session.user ? next() : res.redirect('/login');
}

// Маршруты
app.get('/', (req, res) => res.render('index'));
app.get('/login', (req, res) => res.render('auth/login'));
app.get('/register', (req, res) => res.render('auth/register'));

app.post('/register', async (req, res) => {
  try {
    const { username, email, password, password2 } = req.body;
    if (password !== password2) throw new Error('Пароли не совпадают');

    const connection = await getConnection();
    const [user] = await connection.execute(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );
    
    if (user.length) throw new Error('Email уже зарегистрирован');

    const hash = await bcrypt.hash(password, 10);
    await connection.execute(
      'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
      [username, email, hash]
    );
    
    req.flash('success_msg', 'Регистрация успешна!');
    res.redirect('/login');
  } catch (err) {
    req.flash('error_msg', err.message);
    res.redirect('/register');
  }
});

app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const connection = await getConnection();
    const [users] = await connection.execute(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );
    
    if (!users.length || !(await bcrypt.compare(password, users[0].password))) {
      throw new Error('Неверные данные');
    }

    req.session.user = users[0];
    res.redirect('/create');
  } catch (err) {
    req.flash('error_msg', err.message);
    res.redirect('/login');
  }
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

app.get('/create', ensureAuthenticated, (req, res) => res.render('create'));
app.get('/gallery', async (req, res) => {
  try {
    const connection = await getConnection();
    const [memes] = await connection.execute(`
      SELECT memes.*, users.username 
      FROM memes 
      JOIN users ON memes.user_id = users.id
    `);
    res.render('gallery', { memes });
  } catch (err) {
    req.flash('error_msg', 'Ошибка загрузки галереи');
    res.redirect('/');
  }
});

// Добавленный обработчик для скачивания
app.get('/download/:id', async (req, res) => {
  try {
    const connection = await getConnection();
    const [rows] = await connection.execute(
      'SELECT image_path FROM memes WHERE id = ?',
      [req.params.id]
    );
    
    if (!rows.length) {
      req.flash('error_msg', 'Мем не найден');
      return res.redirect('/gallery');
    }

    const imagePath = path.join(__dirname, 'public', rows[0].image_path);
    
    if (!fs.existsSync(imagePath)) {
      throw new Error('Файл не найден');
    }

    res.download(imagePath);
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при скачивании');
    res.redirect('/gallery');
  }
});

app.post('/create', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) throw new Error('Загрузите изображение');
    
    const connection = await getConnection();
    await connection.execute(
      'INSERT INTO memes (user_id, image_path, top_text, bottom_text) VALUES (?, ?, ?, ?)',
      [
        req.session.user.id,
        `/uploads/${req.file.filename}`,
        req.body.topText,
        req.body.bottomText
      ]
    );

    req.flash('success_msg', 'Мем создан!');
    res.redirect('/gallery');
  } catch (err) {
    req.flash('error_msg', err.message);
    res.redirect('/create');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Сервер запущен на порту ${PORT}`));
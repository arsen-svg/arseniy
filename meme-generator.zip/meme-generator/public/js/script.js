document.addEventListener('DOMContentLoaded', function() {
    // Закрытие уведомлений
    const closeAlert = () => {
      document.querySelectorAll('.close-btn').forEach(button => {
        button.addEventListener('click', function() {
          this.parentElement.style.opacity = '0';
          setTimeout(() => {
            this.parentElement.remove();
          }, 300);
        });
      });
    };
    closeAlert();
  
    // Предпросмотр мема на странице создания
    if (document.getElementById('image')) {
      const imageInput = document.getElementById('image');
      const topTextInput = document.getElementById('topText');
      const bottomTextInput = document.getElementById('bottomText');
      const previewImage = document.getElementById('previewImage');
      const topTextPreview = document.querySelector('.meme-text.top-text');
      const bottomTextPreview = document.querySelector('.meme-text.bottom-text');
  
      // Обработчик загрузки изображения
      imageInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = function(event) {
            previewImage.src = event.target.result;
            previewImage.style.display = 'block';
            previewImage.classList.add('loaded');
          };
          reader.readAsDataURL(file);
        }
      });
  
      // Обновление текста в реальном времени
      topTextInput.addEventListener('input', function() {
        topTextPreview.textContent = this.value;
      });
  
      bottomTextInput.addEventListener('input', function() {
        bottomTextPreview.textContent = this.value;
      });
    }
  
    // Анимация элементов при загрузке
    const animateElements = () => {
      const memeCards = document.querySelectorAll('.meme-card');
      memeCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
        card.classList.add('animate__animated', 'animate__fadeInUp');
      });
  
      const authForm = document.querySelector('.auth-form');
      if (authForm) {
        authForm.classList.add('animate__animated', 'animate__zoomIn');
      }
    };
    animateElements();
  
    // Плавная прокрутка для всех якорей
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
          behavior: 'smooth'
        });
      });
    });
  
    // Валидация форм
    document.querySelectorAll('form').forEach(form => {
      form.addEventListener('submit', function(e) {
        const inputs = this.querySelectorAll('input[required]');
        let isValid = true;
  
        inputs.forEach(input => {
          if (!input.value.trim()) {
            input.classList.add('error');
            isValid = false;
          } else {
            input.classList.remove('error');
          }
        });
  
        if (!isValid) {
          e.preventDefault();
          this.querySelector('.error').focus();
        }
      });
    });
  });